﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Practica03.Logic;
using Practica03.Utils.Extensions;


namespace Practica03.UI
{
    internal class Program
    {
        

        static void Main(string[] args)
        {

            Menu menu = new Menu();
            menu.ShowMenu();
            
        }

        
    }
}
